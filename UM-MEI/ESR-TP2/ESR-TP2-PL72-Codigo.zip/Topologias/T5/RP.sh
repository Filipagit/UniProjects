java -XX:-UsePerfData -cp ../../ RP 10.0.15.1 10.0.1.10 10.0.2.10 10.0.6.10
