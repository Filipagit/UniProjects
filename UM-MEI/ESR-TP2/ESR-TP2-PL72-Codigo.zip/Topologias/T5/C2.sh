java -XX:-UsePerfData -cp ../../ Client 10.0.3.20 10.0.14.1
