java -XX:-UsePerfData -cp ../../ Client 10.0.0.20 10.0.11.1
