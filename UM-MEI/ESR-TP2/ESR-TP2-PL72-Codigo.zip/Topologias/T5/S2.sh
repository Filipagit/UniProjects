java -XX:-UsePerfData -cp ../../ Server 10.0.2.10 movie.Mjpeg movie2.Mjpeg
