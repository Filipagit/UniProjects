java -XX:-UsePerfData -cp ../../ ONode 10.0.15.2 10.0.15.1 10.0.11.1
