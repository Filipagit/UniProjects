java -XX:-UsePerfData -cp ../../ Server 10.0.6.10 movie.Mjpeg movie2.Mjpeg
