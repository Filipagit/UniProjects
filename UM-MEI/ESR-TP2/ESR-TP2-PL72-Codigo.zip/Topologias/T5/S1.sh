java -XX:-UsePerfData -cp ../../ Server 10.0.1.10 movie.Mjpeg movie2.Mjpeg
